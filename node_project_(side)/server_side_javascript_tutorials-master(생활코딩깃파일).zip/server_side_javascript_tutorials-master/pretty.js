function hello(name){
  console.log('Hi,'+name);
}
hello('egoing');
