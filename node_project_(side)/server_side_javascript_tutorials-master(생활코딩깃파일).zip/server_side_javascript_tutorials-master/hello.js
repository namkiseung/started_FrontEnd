console.log('Hello world');
console.log(1+10);
