var o = require('os');
console.log(o.platform());
